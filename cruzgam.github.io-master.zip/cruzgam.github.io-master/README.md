<a href="https://cruzgam.github.io/gema.html">Practica 1 de bootstrap.Grids</a>
<hr>
<a href="https://cruzgam.github.io/adritabla.html">Practica 2 de4 bootstrap. tablas</a>
<hr>
<a href="https://cruzgam.github.io/formularioyboton.html">Practica 3 de bootstrap. formulario y botones</a>
<hr>
<a href="https://cruzgam.github.io/adri1.html">Practica 4 de bootstrap. imágenes</a>
<hr>
<a href="https://cruzgam.github.io/Menu.html">Practica 5 de bootstrap.menu responsivo</a>
<hr>
<a href="https://cruzgam.github.io/iconos.html">Practica 6 de bootstrap.iconos</a>
<hr>
<a href="https://cruzgam.github.io/carousel.html">Practica 7 de bootstrap.carousel</a>
